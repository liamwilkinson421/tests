public class RelationalOps {
    public static void main(String[] args){
        int x = 7;
        int y = 5;
        int a = 5;
        int b = 9;

        // boolean result = x > y ;  Comparative
        // boolean result = x > y && a > b;  AND
        // boolean result = x > y || a < b; OR
        // boolean result = x > y || a < b || a > 1 ;

        // boolean result = a > b;
        // System.out.println(!result);  (!result) result is NOT true 

        System.out.println();

    }
}

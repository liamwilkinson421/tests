public class Array {
    public static void main(String[] args) {
        int nums2[] = new int[4];
        nums2[0] = 1;
        nums2[1] = 2;
        nums2[2] = 6;
        nums2[3] = 9;
        
        // int nums[] = {3,7,2,4};
        // nums[1] = 6;

        for(int i=0;i<=3;i++){
            System.out.println(nums2[i]);
        }

    }
}

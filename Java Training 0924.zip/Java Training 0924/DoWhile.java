public class DoWhile {
    public static void main(String[] args){

        int i = 10;
        do
        {
            System.out.println("Hi " + i);
            i++;
        }while(i<=4);
        
    }
}
